import { DatePipe } from '@angular/common';
import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NbDialogService } from '@nebular/theme';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import Deposit from '../../model/deposit';
import { DepositService } from '../../service/deposit.service';

@Component({
  selector: 'ngx-pending',
  templateUrl: './pending.component.html',
  styleUrls: ['./pending.component.scss'],
})
export class PendingComponent implements OnInit {
  gridApi: any;
  gridColumnApi: any;
  editBankingObj;
  selectedDeposits: Deposit[] = [];

  constructor(
    private depositService: DepositService, 
    private datePipe: DatePipe,
    private dialogService: NbDialogService,
    private modalService: NgbModal,
    private fb:FormBuilder
    ) {
   }

  allDeposit: Deposit[];
  bankingForm: FormGroup;


  ngOnInit(): void {
    this.allDeposit = this.depositService.getAllDeposits();

    this.bankingForm = this.fb.group({
      sheet_date: ['', Validators.required],
      giro_slip: ['', Validators.required],
      banking_total: ['', Validators.required],
      banked_total: ['', Validators.required],
      sealed_by: ['', Validators.required],
      cashup_sheets: [this.selectedDeposits, Validators.required],
      outstanding: ['', Validators.required],
      reason: ['Cash Difference']
    })
  }

  defaultColDef = {
    flex: 1,
    minWidth: 100,
    resizable: true,
  };

  columnDefs = [
    { field: 'sheet_date', headerName:'DATE', sortable: true, checkboxSelection: true, filter: 'agTextColumnFilter',
      headerCheckboxSelection: true, headerCheckboxSelectionFilteredOnly: true,
      valueFormatter: params => this.dateFormatter(params.data.sheet_date)
    },
    { field: 'epos_taking',headerName:'EPOS', sortable: true, filter: 'agTextColumnFilter',
      valueFormatter: params => this.currencyFormatter(params.data.epos_taking, '£')
    },
    { field: 'cash_taking',headerName:'CASH', sortable: true, filter: 'agTextColumnFilter', 
      valueFormatter: params => this.currencyFormatter(params.data.cash_taking, '£')
    },
    { field: 'difference',headerName:'Difference', sortable: true, filter: 'agTextColumnFilter',
      valueFormatter: params => this.currencyFormatter(params.data.difference, '£'),
      cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red', };
      }
      return {color: 'green'};
      }
    },
 
  ];

  onGridReady(params) {
    this.allDeposit = this.depositService.getAllDeposits();

    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

  }

  currencyFormatter(currency, sign) {
    var sansDec = currency
    return sign + ` ${sansDec}`;
  }

  dateFormatter(date:Date){
    var formatted_date = this.datePipe.transform(date, 'dd MMM yyyy')
    return formatted_date;
  }

  @ViewChild('editContent') editContent: TemplateRef<any>;
  createBankingModal() {
   this.editBankingObj ;
   let selectedNodes = this.gridApi.getSelectedNodes();
   let selectedData = selectedNodes.map(node=> node.data);
   console.log(selectedData);
   this.selectedDeposits = selectedData;
  //  this.dialogService.open(this.editContent);
   this.modalService.open(this.editContent, { centered: true, backdrop:true,  windowClass: 'sidebar-modal', size: 'lg' });
 }

 toStr(s:any){
    return JSON.stringify(s);
 }

 addSelectedDeposit(d) {
  let obj = JSON.parse(d)
  if (obj && !this.selectedDeposits.find(x => x.sheet_date == obj.sheet_date)) {
    this.selectedDeposits.push(obj);
  }
}

 removeDeposit(d: Deposit) {
  this.selectedDeposits.splice(this.selectedDeposits.findIndex(x => x.sheet_date == d.sheet_date), 1);
}

 submitCreateBanking(){
   this.bankingForm.value.cashup_sheets = this.selectedDeposits;
  console.log(this.bankingForm.value)
 }
 
}
