import { Component, OnInit } from '@angular/core';
import { DepositService } from '../service/deposit.service';

@Component({
  selector: 'ngx-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.scss'],
})
export class DepositComponent implements OnInit {

  constructor(private depositService: DepositService) { 
    this.prevDate.setDate(this.myDate.getDate()-1) ;
  }

  myDate = new Date();
  prevDate = new Date();
  deposits_filter = "M";
  allDeposit ;
  allBanking;

  ngOnInit(): void {
    this.allDeposit = this.depositService.getAllDeposits();
    this.allBanking = this.depositService.getAllBankings();
  }

  reset_deposits(s:string){
    this.deposits_filter = s;
  }

}
