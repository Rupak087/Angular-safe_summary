export default class  All_Cashup{
    id:number;
    DATE:Date;
    TIME:string;
    EPOS:number;
    CASH: number;
    PDQ: number;
    DELIVERY: number;
    DIFFERENCE:number;
    KPI_TOTAL:number;
    VOID: number;
    DISCOUNT: number;
    REFUNDS: number;
    STATUS:string;
}