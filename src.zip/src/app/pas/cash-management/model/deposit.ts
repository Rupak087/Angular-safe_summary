export default class Deposit{
    id:number;
    sheet_date:Date;
    epos_taking:number;
    cash_taking: number;
    pdq: number;
    delivery: number;
    Void: number;
    discount: number;
    refunds: number;
    difference:number;
    isChecked: boolean;
}

export class Banking{
    id: number;
    sheet_date: Date;
    giro_slip: number;
    banking_total: number;
    outstanding: number;
    sealed_by: string;
    
}