import { Injectable } from '@angular/core';
import Deposit, { Banking } from '../model/deposit';


@Injectable({
  providedIn: 'root'
})
export class DepositService {

  data1 : any ;

  deposits: Deposit[] = [
      {   
          id:1231,
          sheet_date: new Date(2020,11,1),
          epos_taking:8,
          cash_taking: 7,
          pdq: 7.53798,
          delivery: 7,
          Void: 7,
          discount: 7,
          refunds: 7,
          difference:-7,
          isChecked:false
      },
      {   
          id:1232,
          sheet_date: new Date(2020,12,2),
          epos_taking:6,
          cash_taking: 7,
          pdq: 7,
          delivery: 7,
          Void: 7,
          discount: 7,
          refunds: 7,
          difference:7,
          isChecked:false
      },
    {   
        id:1233,
        sheet_date: new Date(2020,12,3),
        epos_taking:9,
        cash_taking: 7,
        pdq: 7,
        delivery: 7,
        Void: 7,
        discount: 7,
        refunds: 7,
        difference:7,
        isChecked:false
    },
    {   
        id:1234,
        sheet_date: new Date(2020,12,4),
        epos_taking:7,
        cash_taking: 7,
        pdq: 7,
        delivery: 7,
        Void: 7,
        discount: 7,
        refunds: 7,
        difference:7,
        isChecked:false
    },
    {   
        id:1235,
        sheet_date: new Date(2020,12,5),
     epos_taking:7,
     cash_taking: 7,
     pdq: 7,
     delivery: 7,
     Void: 7,
     discount: 7,
     refunds: 7,
     difference:7,
     isChecked:false
 },
 {  
    id:1236, 
    sheet_date: new Date(2020,12,6),
   epos_taking:7,
   cash_taking: 7,
   pdq: 7,
   delivery: 7,
   Void: 7,
   discount: 7,
   refunds: 7,
   difference:7,
   isChecked:false
 },
 {  
    id:1237, 
    sheet_date: new Date(2020,12,7),
   epos_taking:7,
   cash_taking: 7,
   pdq: 7,
   delivery: 7,
   Void: 7,
   discount: 7,
   refunds: 7,
   difference:7,
   isChecked:false
 },
 {  
    id:1238, 
    sheet_date: new Date(2020,12,8),
   epos_taking:7,
   cash_taking: 7,
   pdq: 7,
   delivery: 7,
   Void: 7,
   discount: 7,
   refunds: 7,
   difference:7,
   isChecked:false
 },
 {  
    id:1239, 
    sheet_date: new Date(2020,12,9),
   epos_taking:7,
   cash_taking: 7,
   pdq: 7,
   delivery: 7,
   Void: 7,
   discount: 7,
   refunds: 7,
   difference:7,
   isChecked:false
 },
 {  
    id:1240, 
    sheet_date: new Date(2020,12,10),
   epos_taking:7,
   cash_taking: 7,
   pdq: 7,
   delivery: 7,
   Void: 7,
   discount: 7,
   refunds: 7,
   difference:7,
   isChecked:false
 },
 {  
    id:1241, 
    sheet_date: new Date(2020,12,11),
   epos_taking:7,
   cash_taking: 7,
   pdq: 7,
   delivery: 7,
   Void: 7,
   discount: 7,
   refunds: 7,
   difference:7,
   isChecked:false
 },
 {  
    id:1242, 
    sheet_date: new Date(2020,12,12),
   epos_taking:7,
   cash_taking: 7,
   pdq: 7,
   delivery: 7,
   Void: 7,
   discount: 7,
   refunds: 7,
   difference:7,
   isChecked:false
 }
   ]

   bankings: any[]= [
    { 
      id: 1231, 
      sheet_date: new Date(2020,12,1),
      cashup_sheets: [
          {   
          id:1231,
          sheet_date: new Date(2020,11,1),
          epos_taking:8,
          cash_taking: 7,
          pdq: 7.53798,
          delivery: 7,
          Void: 7,
          discount: 7,
          refunds: 7,
          difference:-7,
          isChecked:false
      },
      {   
          id:1232,
          sheet_date: new Date(2020,12,2),
          epos_taking:6,
          cash_taking: 7,
          pdq: 7,
          delivery: 7,
          Void: 7,
          discount: 7,
          refunds: 7,
          difference:7,
          isChecked:false
      },
      ],
      giro_slip: 45671,
      banking_total: 200,
      banked_total: 180,
      outstanding: 120,
      sealed_by: "John Doe",
      reason: "Cash Difference"
    },
    { 
      id: 1232,
      sheet_date: new Date(2020,12,1),
      cashup_sheets: [
          {   
          id:1231,
          sheet_date: new Date(2020,11,1),
          epos_taking:8,
          cash_taking: 7,
          pdq: 7.53798,
          delivery: 7,
          Void: 7,
          discount: 7,
          refunds: 7,
          difference:-7,
          isChecked:false
      },
      {   
          id:1232,
          sheet_date: new Date(2020,12,2),
          epos_taking:6,
          cash_taking: 7,
          pdq: 7,
          delivery: 7,
          Void: 7,
          discount: 7,
          refunds: 7,
          difference:7,
          isChecked:false
      },
      ],
      giro_slip: 45672,
      banking_total: 200,
      banked_total: 180,
      outstanding: -120,
      sealed_by: "John Doe",
      reason: "Cash Difference"
    },
    { 
      id: 1233,
      sheet_date: new Date(2020,12,1),
      cashup_sheets: [
          {   
          id:1231,
          sheet_date: new Date(2020,11,1),
          epos_taking:8,
          cash_taking: 7,
          pdq: 7.53798,
          delivery: 7,
          Void: 7,
          discount: 7,
          refunds: 7,
          difference:-7,
          isChecked:false
      },
      {   
          id:1232,
          sheet_date: new Date(2020,12,2),
          epos_taking:6,
          cash_taking: 7,
          pdq: 7,
          delivery: 7,
          Void: 7,
          discount: 7,
          refunds: 7,
          difference:7,
          isChecked:false
      },
      ],
      giro_slip: 45673,
      banking_total: 200,
      banked_total: 180,
      
      outstanding: 100,
      sealed_by: "John Doe",
      reason: "Cash Difference"
    },
    { 
      id: 1234,
      sheet_date: new Date(2020,12,1),
      cashup_sheets: [
          {   
          id:1231,
          sheet_date: new Date(2020,11,1),
          epos_taking:8,
          cash_taking: 7,
          pdq: 7.53798,
          delivery: 7,
          Void: 7,
          discount: 7,
          refunds: 7,
          difference:-7,
          isChecked:false
      },
      {   
          id:1232,
          sheet_date: new Date(2020,12,2),
          epos_taking:6,
          cash_taking: 7,
          pdq: 7,
          delivery: 7,
          Void: 7,
          discount: 7,
          refunds: 7,
          difference:7,
          isChecked:false
      },
      ],
      giro_slip: 45674,
      banking_total: 200,
      banked_total: 180,
      outstanding: -120,
      sealed_by: "John Doe",
      reason: "Cash Difference"
    },
    { 
      id: 1235,
      sheet_date: new Date(2020,12,1),
      cashup_sheets: [
          {   
          id:1231,
          sheet_date: new Date(2020,11,1),
          epos_taking:8,
          cash_taking: 7,
          pdq: 7.53798,
          delivery: 7,
          Void: 7,
          discount: 7,
          refunds: 7,
          difference:-7,
          isChecked:false
      },
      {   
          id:1232,
          sheet_date: new Date(2020,12,2),
          epos_taking:6,
          cash_taking: 7,
          pdq: 7,
          delivery: 7,
          Void: 7,
          discount: 7,
          refunds: 7,
          difference:7,
          isChecked:false
      },
      ],
      giro_slip: 45675,
      banking_total: 200,
      banked_total: 180,
      outstanding: -60,
      sealed_by: "John Doe",
      reason: ""
    },
    { 
      id: 1236,
      sheet_date: new Date(2020,12,1),
      cashup_sheets: [
          {   
          id:1231,
          sheet_date: new Date(2020,11,1),
          epos_taking:8,
          cash_taking: 7,
          pdq: 7.53798,
          delivery: 7,
          Void: 7,
          discount: 7,
          refunds: 7,
          difference:-7,
          isChecked:false
      },
      {   
          id:1232,
          sheet_date: new Date(2020,12,2),
          epos_taking:6,
          cash_taking: 7,
          pdq: 7,
          delivery: 7,
          Void: 7,
          discount: 7,
          refunds: 7,
          difference:7,
          isChecked:false
      },
      ],
      giro_slip: 45676,
      banking_total: 200,
      banked_total: 180,
      outstanding: 80,
      sealed_by: "John Doe",
      reason: ""
    },
    { 
      id: 1237,
      sheet_date: new Date(2020,12,1),
      cashup_sheets: [
          {   
          id:1231,
          sheet_date: new Date(2020,11,1),
          epos_taking:8,
          cash_taking: 7,
          pdq: 7.53798,
          delivery: 7,
          Void: 7,
          discount: 7,
          refunds: 7,
          difference:-7,
          isChecked:false
      },
      {   
          id:1232,
          sheet_date: new Date(2020,12,2),
          epos_taking:6,
          cash_taking: 7,
          pdq: 7,
          delivery: 7,
          Void: 7,
          discount: 7,
          refunds: 7,
          difference:7,
          isChecked:false
      },
      ],
      giro_slip: 45677,
      banking_total: 200,
      banked_total: 180,
      outstanding: 100,
      sealed_by: "John Doe",
      reason: "Cash Difference"
    },
  ]

  constructor() { }

  getAllDeposits(){
    return this.deposits;
  }

  getDepositById(id: number){
    return this.deposits.find(x=> x.id==id);
  }

  getAllBankings(){
    return this.bankings;
  }

  getBankingById(id: number){
    return this.bankings.find(x=> x.id==id);
  }

  deleteBankingById(id: number){
    this.bankings = this.bankings.filter(x=> x.id != id);
  }
}
