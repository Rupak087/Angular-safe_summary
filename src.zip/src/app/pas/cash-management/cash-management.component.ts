import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-cash-management',
  template: `<router-outlet></router-outlet>`,
})
export class CashManagementComponent {

}
