import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-dashborad',
  templateUrl: './dashborad.component.html',
  styleUrls: ['./dashborad.component.scss'],
})
export class DashboradComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
