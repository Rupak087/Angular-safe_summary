Application-wise data providers.
