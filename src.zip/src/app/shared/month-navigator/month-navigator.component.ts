import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-month-navigator',
  templateUrl: './month-navigator.component.html',
  styleUrls: ['./month-navigator.component.scss'],
})
export class MonthNavigatorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
